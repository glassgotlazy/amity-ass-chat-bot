// Minimal local server for the Amity Lucknow Admission Assistant.
//
// Why this exists: the chatbot itself is a static HTML/JS page, but an OpenAI
// API key can never live safely in client-side JS (anyone can read it from
// page source / devtools the moment this is hosted online). This server does
// two things:
//   1. Serves the static site (index.html and friends).
//   2. Exposes POST /api/chat, which holds the OpenAI key server-side and is
//      the ONLY place that ever talks to OpenAI's API.
//
// The front-end still answers most questions instantly and offline from its
// own local knowledge base — it only calls this endpoint when it has no
// confident local match, so API usage stays minimal.

require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(__dirname));

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const PORT = process.env.PORT || 3000;

// Native fetch (Node 18+) is used directly — no extra dependency needed.

const SYSTEM_CONTEXT = `You are a concise, friendly admissions assistant for Amity University Lucknow.
Ground your answers in these known facts and don't contradict them:
- Amity University Lucknow is a private university under the Ritnand Balved Education Foundation (Amity Education Group), established in 2010.
- Campus: Malhaur (near railway station), Gomti Nagar Extension, Lucknow – 226028, Uttar Pradesh. ~40 acres, 800+ faculty, 210+ labs, library with 70,000+ books.
- Programs: B.Tech, M.Tech, BBA, MBA, BA LLB (Hons), LLM, B.Com (Hons), MCA, M.Des, Pharmacy, Biotechnology, PhD.
- Contact: +91-7303789789, amity.edu/lucknow.
Rules:
- If asked about a specific figure you're not confident about (exact fees, cutoffs, current dates, current test names), say it varies by year and point the user to amity.edu/lucknow or the phone number above instead of guessing.
- Keep answers short — under ~80 words unless the user explicitly asks for more detail.
- Never claim to be an official Amity University representative; you are an unofficial helper.`;

// Very small in-memory rate limiter — keeps this personal/local demo from
// ever running up unexpected API usage or cost, per the "limit API use" brief.
const RATE_LIMIT = 20;          // max requests
const RATE_WINDOW_MS = 60_000;  // per rolling minute
let requestTimestamps = [];
function isRateLimited(){
  const now = Date.now();
  requestTimestamps = requestTimestamps.filter(t => now - t < RATE_WINDOW_MS);
  if(requestTimestamps.length >= RATE_LIMIT) return true;
  requestTimestamps.push(now);
  return false;
}

app.post('/api/chat', async (req, res) => {
  const userMessage = ((req.body && req.body.message) || '').toString().trim().slice(0, 500);

  if(!userMessage){
    return res.status(400).json({ error: 'Empty message.' });
  }
  if(!OPENAI_API_KEY){
    return res.status(500).json({ error: 'Server is missing OPENAI_API_KEY. Add it to your .env file and restart the server.' });
  }
  if(isRateLimited()){
    return res.status(429).json({ error: 'Too many requests — please slow down a bit.' });
  }

  try{
    const body = {
      model: OPENAI_MODEL,
      messages: [
        { role: 'system', content: SYSTEM_CONTEXT },
        { role: 'user', content: userMessage }
      ],
      max_tokens: 400, // reasoning-style models (o1/o3/etc.) use `max_completion_tokens` instead and may reject `temperature` — switch these two lines if you change OPENAI_MODEL to one of those
      temperature: 0.4
    };

    const apiRes = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify(body)
    });
    const data = await apiRes.json();

    if(!apiRes.ok){
      console.error('OpenAI API error:', data);
      return res.status(502).json({ error: 'OpenAI API request failed.' });
    }

    const text = data?.choices?.[0]?.message?.content?.trim();
    if(!text){
      return res.status(502).json({ error: 'OpenAI returned an empty response.' });
    }

    res.json({ reply: text });
  } catch(err){
    console.error('Proxy error:', err);
    res.status(500).json({ error: 'Internal proxy error.' });
  }
});

app.listen(PORT, () => {
  console.log(`Amity chatbot running at http://localhost:${PORT}`);
  if(!OPENAI_API_KEY){
    console.warn('⚠️  OPENAI_API_KEY not set in .env — AI fallback will stay disabled (local knowledge-base answers still work fine).');
  }
});
